<?php
defined ( 'BASEPATH' ) or exit ( 'No direct script access allowed' );
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class Webservice extends CI_Controller
{
    public function __construct() {
        parent::__construct();
            $this->module = "Webservice";
            $this->module_label = "Webservice";
            $this->module_labels = "Webservice";
    }
    
    public function add()
    {
        if(strtoupper($this->input->server('REQUEST_METHOD')) === "POST") 
        {
            $sname = $this->input->post('sname',TRUE);
            $sage = $this->input->post('sage',TRUE);
            $this->form_validation->set_rules('sname','sname','required');
            $this->form_validation->set_rules('sage','sage','required');
            if(($this->form_validation->run()===TRUE) && ($this->input->post(NULL,TRUE))) 
            {
                $getresult = $this->Mydb->adddata($sname,$sage);
                if($getresult=='1')
                {
                    $responseData = array('status' => 1,'error' => '','result' =>'Thank you for registration with us');
                    $this->output->set_content_type('application/json'); 
                    $this->output->set_header('Access-Control-Allow-Origin: *');
                    return $this->output->set_output(json_encode($responseData));
                }
                else
                {
                    $responseData = array('status' => 2,'error' => 'Try again','result' =>'');
                    $this->output->set_content_type('application/json'); 
                    $this->output->set_header('Access-Control-Allow-Origin: *');
                    return $this->output->set_output(json_encode($responseData));
                }
            }
            else
            {
                    $responseData = array('status' => 2,'error' => 'Try again','result' =>'');
                    $this->output->set_content_type('application/json'); 
                    $this->output->set_header('Access-Control-Allow-Origin: *');
                    return $this->output->set_output(json_encode($responseData));
            }
        }
        else
        {
                $responseData = array('status' => 3,'error' => 'Missing Parametter','result' =>'');
                $this->output->set_content_type('application/json'); 
                $this->output->set_header('Access-Control-Allow-Origin: *');
                return $this->output->set_output(json_encode($responseData));
        }
    }
    
    public function viewdata()
    {
        $responseData = array('status' => 1,'error' => '','result' =>$this->Mydb->viewdata());
        $this->output->set_content_type('application/json'); 
        $this->output->set_header('Access-Control-Allow-Origin: *');
         return $this->output->set_output(json_encode($responseData));
    }
}

