<?php
defined ( 'BASEPATH' ) or exit ( 'No direct script access allowed' );
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class Mydb extends CI_Model
{
    public function __construct() {
        parent::__construct();
    }
    
    public function adddata($sname,$sage)
    {
        $storedata=$this->db->query('insert into student(sname,sage)values(?,?)',array($sname,$sage));
        return 1;
    }
    
    public function viewdata()
    {
        $viewdata= $this->db->query('select sid as student_id, sname as student_name, sage as student_age from student');
        return $viewdata->result();
    }
}

